import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import fs from "fs";
import fetch from "node-fetch";
import readline from "readline";
import Polyline from "@mapbox/polyline";
import axios from "axios";
import { Console } from "console";

const app = express();
const server = createServer(app);
const io = new Server(server);
const port = 3000;

const usersFile = "usersInfo.json";
const announcementsFile = "announcementsInfo.json";

// Viagens a decorrer associadas a conexão de socket
const realTimeInfo = [];
// Users à espera de resposta
const tripRequestsAwait = [];

server.listen(port, () => console.log("Server running on port: " + port));

// Processamento de dados JSON
const tripsBuffer = fs.readFileSync(announcementsFile);
let tripsString = tripsBuffer.toString();
var tripsJSON = JSON.parse(tripsString);
var drivers_connected = tripsJSON.announcements;
drivers_connected.pop();
var numDrivers = drivers_connected.length;

const linksBuffer = fs.readFileSync("links.json");
let linksString = linksBuffer.toString();
var links = JSON.parse(linksString);

function createCopyOfPathFile(idAnnouncement) {
  DeletePathFile(idAnnouncement);
  fs.copyFile(
    "path_" + idAnnouncement + ".txt",
    "path_" + idAnnouncement + "_IN_USE.txt",
    (err) => {
      if (err) throw err;
    }
  );
}

function DeletePathFile(idAnnouncement) {
  let path = "path_" + idAnnouncement + "_IN_USE.txt";
  if (fs.existsSync(path)) {
    fs.unlinkSync(path);
  }
}

// Simulação de viagens através de coordenadas em ficheiros
async function processLineByLine(idAnnouncement, linha) {
  const fileStream = fs.createReadStream(
    "path_" + idAnnouncement + "_IN_USE.txt",
    (err) => {
      if (err) console.log(err);
    }
  );
  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity,
  });

  let cntr = 0;
  let haLinha = false;

  rl.on("line", function (line) {
    if (cntr++ == linha) {
      haLinha = true;
      //console.log(idAnnouncement + ": " + line);
      if (line.valueOf() !== "end".valueOf()) {
        let lineinfo = JSON.parse(line);
        realTimeInfo.find((t) => t.idAnnouncement === idAnnouncement).location =
          { latitude: lineinfo.lat, longitude: lineinfo.long };
      } else {
        console.log(
          "A viagem com idAnnouncement " + idAnnouncement + " terminou"
        );
        finishTrip(idAnnouncement);
      }
    }
  });
}

var linha = 0;
let trips = [1, 2, 3, 4, 5];

function changeCoordinates() {
  for (let i = 0; i < trips.length; i++) {
    if (linha === 0) {
      console.log("A viagem com id " + trips[i] + " foi iniciada");
    }
    processLineByLine(trips[i], linha);
    if (
      typeof drivers_connected.find((t) => t.idAnnouncement === trips[i]) ===
      "undefined"
    ) {
      DeletePathFile(trips[i]);
      trips.splice(i, 1);
    }
  }
  linha++;
}

createCopyOfPathFile(1);
createCopyOfPathFile(2);
createCopyOfPathFile(3);
createCopyOfPathFile(4);
createCopyOfPathFile(5);
realTimeInfoPopulate(1, "", {
  latitude: drivers_connected.find((t) => t.idAnnouncement === 1).origin.lat,
  longitude: drivers_connected.find((t) => t.idAnnouncement === 1).origin.long,
});
realTimeInfoPopulate(2, "", {
  latitude: drivers_connected.find((t) => t.idAnnouncement === 2).origin.lat,
  longitude: drivers_connected.find((t) => t.idAnnouncement === 2).origin.long,
});
realTimeInfoPopulate(3, "", {
  latitude: drivers_connected.find((t) => t.idAnnouncement === 3).origin.lat,
  longitude: drivers_connected.find((t) => t.idAnnouncement === 3).origin.long,
});
realTimeInfoPopulate(4, "", {
  latitude: drivers_connected.find((t) => t.idAnnouncement === 4).origin.lat,
  longitude: drivers_connected.find((t) => t.idAnnouncement === 4).origin.long,
});
realTimeInfoPopulate(5, "", {
  latitude: drivers_connected.find((t) => t.idAnnouncement === 5).origin.lat,
  longitude: drivers_connected.find((t) => t.idAnnouncement === 5).origin.long,
});
setInterval(changeCoordinates, 4000);

function finishTrip(ID) {
  for (var i = 0; i < drivers_connected.length; i++) {
    if (drivers_connected[i].idAnnouncement === ID) {
      drivers_connected.splice(i, 1);
      break;
    }
  }

  for (var i = 0; i < realTimeInfo.length; i++) {
    if (realTimeInfo[i].idAnnouncement === ID) {
      realTimeInfo.splice(i, 1);
      break;
    }
  }

  console.log(realTimeInfo);

  --numDrivers;
}

// Função que tira partido da API de direções do Google Maps para recalcular caminho após o condutor aceitar dar uma boleia
function recalcularCoordenadas(origin, waypoint, destination, idAnnouncement) {
  axios
    .get(
      `https://maps.googleapis.com/maps/api/directions/json?origin=${origin.latitude},${origin.longitude}&destination=${destination.latitude},${destination.longitude}&waypoints=via:${waypoint.latitude},${waypoint.longitude}&mode=driving&key=${links.GOOGLE_MAPS_APIKEY}`
    )
    .then((result) => result.data)
    .then((result) => {
      let array = Polyline.decode(result.routes[0].overview_polyline.points);

      let coordinates = array.map((point) => {
        return {
          lat: point[0],
          long: point[1],
        };
      });

      let filename = "path_" + idAnnouncement + "_IN_USE.txt";

      fs.truncate(filename, 0, function () {
        console.log("done");
      });
      var file = fs.createWriteStream(filename);
      file.on("error", function (err) {
        /* error handling */
      });
      coordinates.forEach(function (v) {
        file.write(JSON.stringify(v) + "\n");
      });
      file.write("end");
      file.end();
    })
    .catch((er) => console.log(er.message));
}

function tripRequest(idAnnouncement, pickupLocation, user_socket, username) {
  const trip = realTimeInfo.find(
    (t) => t.idAnnouncement === parseInt(idAnnouncement)
  );

  const trip_info = drivers_connected.find(
    (t) => t.idAnnouncement === parseInt(idAnnouncement)
  );

  const DriverSocketID = trip.socket;

  let response = null;
  let answered = false;

  // Pedido a viagem simulada
  if (DriverSocketID.valueOf() === "") {
    // Aceitar viagem
    response = true;
    answered = true;

    let destination_aux = {
      longitude: trip_info.destination.long,
      latitude: trip_info.destination.lat,
    };

    if (response && answered) {
      recalcularCoordenadas(
        trip.location,
        pickupLocation,
        destination_aux,
        idAnnouncement
      );
      linha = 0;
    }
    console.log("Recalcular coordenadas de viagem fictícia");
  }

  tripRequestsAwait.push({
    idAnnouncement: idAnnouncement,
    socket: user_socket,
    response: response,
    answered: answered,
  });

  io.to(DriverSocketID).emit("TripRequest", [pickupLocation, username]);
}

function getTripSimulation(pickupLocation, idAnnouncement) {
  //Position of the trip at the moment
  let trip = drivers_connected.find(
    (t) => t.idAnnouncement === parseInt(idAnnouncement)
  );
  let pathSize = trip.waypoints.length - 1;
  let driverLocation = realTimeInfo.find(
    (t) => t.idAnnouncement === parseInt(idAnnouncement)
  ).location;

  let driverDestination_aux = {
    latitude: trip.destination.lat,
    longitude: trip.destination.long,
  };

  recalcularCoordenadas(
    driverLocation,
    pickupLocation,
    driverDestination_aux,
    idAnnouncement
  );
  linha = 0;
}

function realTimeInfoPopulate(id, sckt, loc) {
  const tripRealTime = {
    idAnnouncement: id,
    socket: sckt,
    location: loc,
  };
  realTimeInfo.push(tripRealTime);
}

io.on("connection", (socket) => {
  console.log("A user has connected");

  socket.on("error", function (err) {
    console.log("Socket.IO Error");
    console.log(err.stack);
  });

  //Atualiza a posição de uma viagem que esteja a decorrer
  socket.on("update location", function (data) {
    let trip = realTimeInfo.find((t) => t.idAnnouncement === data[0]);

    if (typeof trip !== "undefined") {
      trip.location = data[1];
    }
  });

  // Get info about the on going trips
  socket.on("get driver", (callback) => {
    //console.log("A user has requested info about the ongoing trips");
    callback([drivers_connected, realTimeInfo]);
  });

  // Get real time info about a specific trip
  socket.on("get driver by ID", function (data, callback) {
    callback(realTimeInfo.find((t) => t.idAnnouncement == data));
  });

  // End trip
  socket.on("endTrip", function (data) {
    console.log("A trip has ended");
    finishTrip(data);
  });

  socket.on("loadDriverInfo", function (data, callback) {
    realTimeInfoPopulate(data[0], data[1], data[2]);
    startTripByIdSimulation(data[0]);
    console.log("Viagem com id: " + data[0] + " começou");
    //getUsersAnnouncementsSimulation(data[0], callback);
    //getUsersAnnouncementsCSS(data, callback);
  });

  // Fazer pedido de viagem
  socket.on("pickup", function (data, callback) {
    let username = getTripData(data[3], "")[0];
    tripRequest(data[0], data[1], data[2], username);

    callback(
      realTimeInfo.find((t) => t.idAnnouncement === parseInt(data[0])).location
    );
  });

  socket.on("tripResponse", function (data) {
    //data = idannouncement
    const trip = tripRequestsAwait.find(
      (t) => t.idAnnouncement === data[0] + ""
    );
    trip.answered = true;
    trip.response = data[1];
    console.log("O driver respondeu");
  });

  socket.on("getTripResponse", function (data, callback) {
    //data = idannouncement
    const trip = tripRequestsAwait.find((t) => t.socket === data);
    callback([trip.answered, trip.response]);
  });

  socket.on("getTripInfo", function (data, callback) {
    //data = idannouncement

    const driver_id = drivers_connected.find(
      (t) => t.idAnnouncement === parseInt(data)
    ).idUser;

    const vehicle_id = drivers_connected.find(
      (t) => t.idAnnouncement === parseInt(data)
    ).idVehicle;

    callback(getTripData(driver_id, vehicle_id));
  });

  // Login
  socket.on("login", function (data, callback) {
    getLoginSimulation(data, callback);
    //getLoginCSS(data, callback);
  });

  // Self Profile
  socket.on("selfProfile", function (data, callback) {
    getSelfProfileSimulation(data, callback);
    //getSelfProfileCSS(data, callback);
  });
  // Profile
  socket.on("profile", function (data, callback) {
    getProfileSimulation(data, callback);
    //getProfileCSS(data, callback);
  });
  socket.on("announcement", function (data, callback) {
    getAnnouncementSimulation(data, callback);
    //getAnnouncementCSS(data, callback);
  });

  socket.on("selfAnnouncement", function (data, callback) {
    getUsersAnnouncementsSimulation(data, callback);
    //getUsersAnnouncementsCSS(data, callback);
  });
});

////////////////// Simulations /////////////////

//USER RELATED
function getLoginSimulation(data, callback) {
  let status = 0;
  let idUser = "";
  let username = data[0];
  let password = data[1];

  const buffer = fs.readFileSync(usersFile);
  let docString = buffer.toString();
  let json = JSON.parse(docString);
  let loginList = json.login;

  for (const userL of loginList) {
    if (userL.email == username && userL.password == password) {
      idUser = userL.idUser;
      break;
    }
  }
  if (idUser != "") {
    callback([true, idUser]);
  } else {
    callback([false, 0, "Email ou password incorretos. Tente novamente."]);
  }
}

function getSelfProfileSimulation(data, callback) {
  const buffer = fs.readFileSync(usersFile);
  let docString = buffer.toString();
  let json = JSON.parse(docString);
  let usersList = json.users;
  let found = false;

  for (const user of usersList) {
    if (user.idUser == data) {
      found = true;
      // 0 for simulation
      callback([true, 0, user]);
      break;
    }
  }
  if (!found) {
    callback([false, "Algo correu mal, utilizador não encontrado."]);
  }
}

function getTripData(userId, vehicleId) {
  const buffer = fs.readFileSync(usersFile);
  let docString = buffer.toString();
  let json = JSON.parse(docString);
  let usersList = json.users;

  const tripInfo = [];

  for (const user of usersList) {
    if (user.idUser == userId) {
      tripInfo.push(user.userName);
      for (const vehicle of user.vehicles) {
        if (vehicle.idVehicle == vehicleId) {
          tripInfo.push(vehicle.brand);
          tripInfo.push(vehicle.model);
          tripInfo.push(vehicle.vehiclePlate);
          break;
        }
        break;
      }
    }
  }
  return tripInfo;
}

function getProfileSimulation(data, callback) {
  const buffer = fs.readFileSync(usersFile);
  let docString = buffer.toString();
  let json = JSON.parse(docString);
  let usersList = json.users;
  let found = false;

  for (const user of usersList) {
    if (user.idUser == data) {
      found = true;
      const userInfo = [user.userName, user.prestige];
      callback([true, userInfo]);
      break;
    }
  }
  if (!found) {
    callback([false, "Algo correu mal, utilizador não encontrado."]);
  }
}

//START TRIP
function startTripByIdSimulation(announcementId) {
  const buffer = fs.readFileSync(announcementsFile);
  let docString = buffer.toString();
  let json = JSON.parse(docString);
  let announList = json.announcements;
  let found = false;

  for (const announ of announList) {
    if (announ.idAnnouncement == announcementId) {
      found = true;
      drivers_connected.push(announ);
      ++numDrivers;
      break;
    }
  }
  if (!found) {
    console.log("A viagem não foi iniciada.");
  }
}

//ANNOUNCEMENT
function getAnnouncementSimulation(data, callback) {
  const buffer = fs.readFileSync(announcementsFile);
  let docString = buffer.toString();
  let json = JSON.parse(docString);
  let announList = json.announcements;
  let found = false;

  for (const announ of announList) {
    if (announ.idAnnouncement == data) {
      found = true;
      callback([true, announ]);
      break;
    }
  }
  if (!found) {
    callback([false, "Algo correu mal, viagem não encontrada."]);
  }
}

function getUsersAnnouncementsSimulation(data, callback) {
  const buffer = fs.readFileSync(announcementsFile);
  let docString = buffer.toString();
  let json = JSON.parse(docString);
  let announList = json.announcements;

  let usersAnnounList = [];
  //console.log(data);
  for (const announ of announList) {
    if (announ.idUser == data) {
      usersAnnounList.push(announ);
    }
  }
  if (usersAnnounList.length == 0) {
    callback([false, "Utilizador não possui viagens."]);
  } else {
    callback([true, usersAnnounList]);
  }
}

////////////////////////////// TODO /////////////////////////////
function getAllAnnouncementsSimulation(data, callback) {
  const buffer = fs.readFileSync(announcementsFile);
  let docString = buffer.toString();
  let json = JSON.parse(docString);
  let announList = json.announcements;

  for (const announ of announList) {
    if (announ.idUser == idUser) {
      found = true;
      const userInfo = [user.userName, user.prestige];
      callback([true, announList]);
      break;
    }
  }
  if (!found) {
    callback([false, "Algo correu mal, utilizador não encontrado."]);
  }
}
function subscribeAnnouncementSimulation(data, callback) {
  const buffer = fs.readFileSync(announcementsFile);
  let docString = buffer.toString();
  let json = JSON.parse(docString);
  let announList = json.announcements;
  let found = false;

  for (const user of announList) {
    if (user.idUser == data) {
      found = true;
      const userInfo = [user.userName, user.prestige];
      callback([true, userInfo]);
      break;
    }
  }
  if (!found) {
    callback([false, "Algo correu mal, utilizador não encontrado."]);
  }
}
function acceptSubstriptionSimulation(data, callback) {
  const buffer = fs.readFileSync(announcementsFile);
  let docString = buffer.toString();
  let json = JSON.parse(docString);
  let announList = json.announcements;
  let found = false;

  for (const user of announList) {
    if (user.idUser == data) {
      found = true;
      const userInfo = [user.userName, user.prestige];
      callback([true, userInfo]);
      break;
    }
  }
  if (!found) {
    callback([false, "Algo correu mal, utilizador não encontrado."]);
  }
}

//////////////// CSS API  ///////////////////

//USER RELATED
function getLoginCSS(data, callback) {
  const requestOptions = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: data[0], password: data[1] }),
  };

  fetch(links.linkuser + "login", requestOptions)
    .then((response) => {
      const statusCode = response.status;
      const data = response.json();
      return Promise.all([statusCode, data]);
    })
    .then((res) => {
      let status = res[0];
      let response = res[1];
      //success
      if (status == 200) {
        callback([true, response.idUser]);
      } else {
        //error
        callback([false, 0, "Email ou password incorretos. Tente novamente."]);
      }
    })
    .catch(function (error) {
      callback([false, 1, "Algo correu mal no login: " + error.message]);
    });
}
function getSelfProfileCSS(data, callback) {
  let link = links["linkuser"] + "profile?idUser=" + data;

  fetch(link)
    .then((response) => {
      const statusCode = response.status;
      const data = response.json();
      return Promise.all([statusCode, data]);
    })
    .then((res) => {
      let status = res[0];
      let response = res[1];
      //success
      if (status == 200) {
        // 1 for api
        callback([true, 1, response]);
      } else {
        //error
        callback([false, 1, "Algo correu mal, utilizador não encontrado."]);
      }
    })
    .catch(function (error) {
      callback([false, 1, "Algo correu mal: " + error.message]);
    });
}
function getProfileCSS(data, callback) {
  let link = links["linkuser"] + "profile?idUser=" + data;

  fetch(link)
    .then((response) => {
      const statusCode = response.status;
      const data = response.json();
      return Promise.all([statusCode, data]);
    })
    .then((res) => {
      let status = res[0];
      let response = res[1];
      //success
      if (status == 200) {
        const userInfo = [userName, prestige];
        callback([true, userInfo]);
      } else {
        //error
        callback([false, "Algo correu mal."]);
      }
    })
    .catch(function (error) {
      callback([false, "Algo correu mal: " + error.message]);
    });
}

//ANNOUNCEMENT RELATED
function getAnnouncementCSS(data, callback) {
  var link = links.linkannouncement + "?idAnnouncement=" + data;
  fetch(link)
    .then((response) => {
      const statusCode = response.status;
      const data = response.json();
      return Promise.all([statusCode, data]);
    })
    .then((res) => {
      var status = res[0];
      var response = res[1];

      if (status == 200) {
        callback([true, response.announcement]);
      } else {
        callback([false, "Algo correu mal, viagem não encontrada."]);
      }
    })
    .catch(function (error) {
      callback([false, "Algo correu mal, viagem não encontrada."]);
    });
}
function getUsersAnnouncementsCSS(data, callback) {
  let link = links.linkannouncement + "/s?idUser=" + data;

  fetch(link)
    .then((response) => {
      const statusCode = response.status;
      const data = response.text();
      return Promise.all([statusCode, data]);
    })
    .then((res) => {
      if (status == 200) {
        console.log("Aqui está uma lista");
      } else {
        callback([false, "Utilizador não possui viagens."]);
      }
    })
    .catch(function (error) {
      callback([false, "Utilizador não possui viagens."]);
    });
}

////////////////////////////// TODO /////////////////////////////
function getAllAnnouncementsCSS(data, callback) {
  let link =
    links.linkannouncement + "/s?detailed=true&community=" + "daBoleias";

  fetch(link)
    .then((response) => {
      const statusCode = response.status;
      const data = response.json();
      return Promise.all([statusCode, data]);
    })
    .then((res) => {
      let status = res[0];
      let response = res[1];

      if (status == 200) {
        let idAnnouncement = response[2].announcement.idAnnouncement;
        console.log("get all " + idAnnouncement);
      } else {
        //algo correu mal
      }
    })
    .catch(function (error) {
      console.log("Algo correu mal: " + error.message);
    });
}
function subscribeAnnouncementCSS(data, callback) {
  let link =
    LINK_URLA +
    "/subscribe?idAnnouncement=" +
    idAnnouncement +
    "&idUser=" +
    userId +
    "&community=" +
    community;

  fetch(link)
    .then((response) => {
      const statusCode = response.status;
      const data = response.json();
      return Promise.all([statusCode, data]);
    })
    .then((res) => {
      let status = res[0];
      let response = res[1];

      if (status == 200) {
        //já se juntou ao anuncio com sucesso
      } else {
        //algo correu mal
      }
    })
    .catch(function (error) {
      alert("Algo correu mal no perfil. Tente de novo.");
      console.log("Algo correu mal no perfil. : " + error.message);
    });
}
function acceptSubstriptionCSS(data, callback) {
  let link =
    LINK_URLA +
    "/subscribe?idAnnouncement=" +
    idAnnouncement +
    "&idUser=" +
    userId +
    "&consent=" +
    consent;

  fetch(link, { method: "DELETE" })
    .then((response) => {
      const statusCode = response.status;
      const data = response.json();
      return Promise.all([statusCode, data]);
    })
    .then((res) => {
      let status = res[0];
      let response = res[1];
      if (status == 200) {
        //já se juntou ao anuncio com sucesso
        let response = res[1];
      } else {
        //algo correu mal
      }
    })
    .catch(function (error) {
      alert("Algo correu mal no perfil. Tente de novo.");
      console.log("Algo correu mal no perfil. : " + error.message);
    });
}
