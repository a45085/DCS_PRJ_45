import * as Location from "expo-location";

export async function _getLocationAsync() {
  let { status } = await Location.requestForegroundPermissionsAsync();
  if ((status = !"granted"))
    console.log("Permission to access location was denied.");

  let location = await Location.getCurrentPositionAsync({
    accuracy: Location.Accuracy.High,
  });

  const auxLocation = {
    lat: location.coords.latitude,
    lng: location.coords.longitude,
  };

  return auxLocation;
}
