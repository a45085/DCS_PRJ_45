import axios from "axios";
import Polyline from "@mapbox/polyline";
// import fs from "fs";

let waypoints = [];
let lastPos = null;

async function recalcularCoordenadas(origin, destination, waypoint) {
  let mapsURL = null;

  if (typeof waypoint === "undefined" || waypoint === null) {
    mapsURL = `https://maps.googleapis.com/maps/api/directions/json?origin=${origin.lat},${origin.long}&destination=${destination.lat},${destination.long}&mode=driving&key=AIzaSyDbSQ8TQMAXO0Uo5mIah6WrBISdw6VO3sw`;
  } else {
    mapsURL = `https://maps.googleapis.com/maps/api/directions/json?origin=${origin.lat},${origin.long}&destination=${destination.lat},${destination.long}&waypoints=via:${waypoint.latitude},${waypoint.longitude}&mode=driving&key=AIzaSyDbSQ8TQMAXO0Uo5mIah6WrBISdw6VO3sw`;
  }
  axios
    .get(mapsURL)
    .then((result) => result.data)
    .then((result) => {
      let array = Polyline.decode(result.routes[0].overview_polyline.points);

      waypoints = array.map((point) => {
        return {
          latitude: point[0],
          longitude: point[1],
        };
      });
    })
    .catch((er) => console.log(er.message));
}

export async function getLocationSimulation(
  origin,
  destination,
  simulation_index,
  waypoint
) {
  let aux_location = null;

  if (simulation_index === 0 && waypoint === null && waypoints.length < 1) {
    console.log("Calculo de coordenadas original");
    await recalcularCoordenadas(origin, destination);
  } else if (waypoint !== null && simulation_index === 0) {
    console.log("Calculo de coordenadas c/ waypoint");
    await recalcularCoordenadas(lastPos, destination, waypoint);
  }

  if (waypoints.length > simulation_index && waypoints.length > 0) {
    aux_location = waypoints[simulation_index];
    lastPos = { lat: aux_location.latitude, long: aux_location.longitude };
  }

  if (simulation_index > waypoints.length && waypoints.length > 0) {
    return null;
  }

  return aux_location;
}
