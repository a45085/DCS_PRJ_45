import React, { useState, useRef, useEffect } from "react";
import { setConfirmEnd, selectConfirmEnd } from "../slices/navSlice";
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Animated,
  Modal,
  BackHandler,
  ActivityIndicator,
  Image,
} from "react-native";
import tw from "tailwind-react-native-classnames";
import { useNavigation } from "@react-navigation/native";
import { useDispatch } from "react-redux";
import { setTripState } from "../slices/navSlice";
import { Icon } from "react-native-elements";

const ModalPopup = ({ visible, children }) => {
  const [showModal, setShowModal] = useState(visible);

  const scaleValue = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    toggleModal();
  }, [visible]);

  const toggleModal = () => {
    if (visible) {
      setShowModal(true);
      Animated.spring(scaleValue, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
    } else {
      setTimeout(() => setShowModal(false), 200);
      Animated.timing(scaleValue, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    }
  };
  return (
    <View>
      <Modal transparent visible={showModal}>
        <Animated.View style={styles.modalBackGround}>
          <View style={[styles.modalContainer]}>{children}</View>
        </Animated.View>
      </Modal>
    </View>
  );
};

const ModalPassenger = ({ Loading, Confirmed, tripEnd }) => {
  const navigation = useNavigation();
  const [visible, setVisible] = useState(true);

  functionCombined = () => {
    BackHandler.addEventListener("hardwareBackPress", function () {
      return false;
    });
    navigation.pop(2);
  };

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <ModalPopup visible={visible}>
        <View style={{ alignItems: "center" }}>
          {Loading && !tripEnd ? (
            <Text style={tw`text-center text-lg`}>
              O condutor foi informado do seu pedido. Por favor aguarde.
            </Text>
          ) : Confirmed && !tripEnd ? (
            <Text style={tw`text-center text-lg`}>
              O condutor aceitou a sua viagem
            </Text>
          ) : !tripEnd ? (
            <Text style={tw`text-center text-lg`}>
              O condutor não está disponível
            </Text>
          ) : null}

          {Loading && !tripEnd ? (
            <>
              <ActivityIndicator style={tw`p-4`} size="large" color="#ababab" />
            </>
          ) : Confirmed && !tripEnd ? (
            <View>
              <View
                style={tw`mt-6 w-16 h-16 self-center border-2 justify-center border-green-400 rounded-full`}
              >
                <Icon
                  style={tw`w-16 h-16 self-center justify-center rounded-full`}
                  name="checkmark-outline"
                  color="green"
                  type="ionicon"
                />
              </View>
              <TouchableOpacity
                onPress={() => {
                  setVisible(false);
                }}
              >
                <Text
                  style={tw`text-lg p-1 text-white bg-black mt-8 rounded-full px-4`}
                >
                  Fechar
                </Text>
              </TouchableOpacity>
            </View>
          ) : !tripEnd ? (
            <View>
              <View
                style={tw`mt-6 w-16 h-16 self-center border-2 justify-center border-red-400 rounded-full`}
              >
                <Icon
                  style={tw`w-16 h-16 self-center justify-center rounded-full`}
                  name="close-outline"
                  color="red"
                  type="ionicon"
                />
              </View>
              <TouchableOpacity
                onPress={() => {
                  navigation.goBack();
                }}
              >
                <Text
                  style={tw`text-lg p-1 text-white bg-black mt-8 rounded-full px-4`}
                >
                  Voltar às viagens
                </Text>
              </TouchableOpacity>
            </View>
          ) : null}
          {tripEnd ? (
            <>
              <Text style={tw`text-center text-2xl`}>A viagem terminou</Text>
              <TouchableOpacity
                style={tw`w-10/12  mt-5 bg-gray-300 mx-auto rounded-full items-center p-3`}
                onPress={() => functionCombined()}
              >
                <Text style={tw`text-lg p-4 mx-1 font-bold  rounded-full px-5`}>
                  Página Inicial
                </Text>
              </TouchableOpacity>
            </>
          ) : null}
        </View>
      </ModalPopup>
    </View>
  );
};

export default ModalPassenger;

const styles = StyleSheet.create({
  title: {
    marginBottom: 15,
    fontSize: 25,
    textAlign: "center",
    fontWeight: "bold",
  },
  text: {
    marginVertical: 5,
    fontSize: 17,
    textAlign: "center",
    flexShrink: 1,
  },
  textTitle: {
    marginVertical: 5,
    fontSize: 17,
    textAlign: "center",
    fontWeight: "bold",
  },
  textRows: {
    flexDirection: "row",
    width: "100%",
    justifyContent: "center",
  },
  modalBackGround: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    width: "90%",
    backgroundColor: "white",
    paddingHorizontal: 20,
    paddingVertical: 40,
    borderRadius: 20,
    elevation: 20,
  },
  header: {
    flexDirection: "column",
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
});
