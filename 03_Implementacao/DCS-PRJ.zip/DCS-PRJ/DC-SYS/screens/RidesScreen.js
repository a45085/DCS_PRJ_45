import React, { useState, useEffect, useRef, useContext } from "react";
import {
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Text,
  View,
  Image,
  SafeAreaView,
  Dimensions,
} from "react-native";
import tw from "tailwind-react-native-classnames";
import MapView, {
  Callout,
  Marker,
  MarkerAnimated,
  AnimatedRegion,
} from "react-native-maps";
import { useNavigation } from "@react-navigation/native";
import {
  setLocation,
  setOrigin,
  setDestination,
  selectDestination,
  selectOrigin,
  setTripID,
  selectTripID,
} from "../slices/navSlice";
import { Icon } from "react-native-elements/dist/icons/Icon";
import TravelScreen from "./TravelScreen";
import { GOOGLE_MAPS_APIKEY } from "@env";
import MapViewDirections from "react-native-maps-directions";
import { _getLocationAsync } from "../getLocation";
import { useDispatch, useSelector } from "react-redux";
import { SocketContext } from "../service/socket";
import * as Animatable from "react-native-animatable";

const screen = Dimensions.get("window");
const ASPECT_RATIO = screen.width / screen.height;
const LATITUDE_DELTA = 0.0922;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

const data = [];
const trip_markers = [];
const animatedRegions = [];
const onMap = [];
let selected = false;

let solo_directions = null;
const directions = [];
let tripName = null;
let selectedMarker = null;

const RidesScreen = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();

  const socket = useContext(SocketContext);

  const [tripOrigin, setTripOrigin] = useState(null);
  const [tripDestination, setTripDestination] = useState(null);
  const mapRef = useRef(null);

  let [, update] = useState();
  const [ServerInfoLoaded, setServerInfoLoaded] = useState(false);
  const [UserInfoLoaded, setUserInfoLoaded] = useState(false);
  const [MyLocation, setMyLocation] = useState(null);

  //  ----------------------------------------------------------------
  // Posição do utilizador

  useEffect(() => {
    const interval = setInterval(() => {
      let mounted = true;
      _getLocationAsync().then((data) => {
        if (mounted) {
          setMyLocation(data);
        }
      });
    }, 3000);
    return function cleanup() {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    if (MyLocation !== null) {
      setUserInfoLoaded(true);
      update({});
    }
  }, [MyLocation]);

  // -------------------------------------------------------------------------
  // Emitir pedido para verificar se há mais carros e atualizar posição dos já existentes

  function filterById(jsonObject, id) {
    return jsonObject.filter(function (jsonObject) {
      return jsonObject["idAnnouncement"] == id;
    })[0];
  }

  function deleteTrip(idAnnouncement) {
    let isLast = false;
    const tripToDelete = filterById(onMap, idAnnouncement);
    const index = tripToDelete.index;
    if (tripToDelete.index === onMap.length - 1) {
      isLast = true;
    }
    console.log("Viagem do " + idAnnouncement + " terminou ");
    selected = false;
    animatedRegions.splice(index, 1);
    trip_markers.splice(index, 1);
    directions.splice(index, 1);
    data.splice(index, 1);
    onMap.splice(index, 1);

    //reduzir o index das seguintes se não for a ultima
    if (!isLast) {
      for (let i = tripToDelete.index; i < onMap.length; i++) {
        onMap[i].index--;
      }
    }
  }

  useEffect(() => {
    const interval = setInterval(() => {
      socket.emit("get driver", (response) => {
        // Percorre todos as viagens que estão a decorrer ( data[i].idannouncement )
        for (let i = 0; i < data.length; i++) {
          const trip = filterById(response[0], data[i].idAnnouncement);
          if (typeof trip === "undefined") {
            deleteTrip(data[i].idAnnouncement);
          }
        }

        var count = Object.keys(response[1]).length;
        for (let i = 0; i < count; i++) {
          if (typeof response[0][i] !== "undefined") {
            // percorre os elementos de data e vê se há algum elemento com idAnnouncement
            const trip = filterById(data, response[0][i].idAnnouncement);

            const location = filterById(
              response[1],
              response[0][i].idAnnouncement
            ).location;

            if (typeof trip === "undefined") {
              data.push({
                idAnnouncement: response[0][i].idAnnouncement,
                origin: response[0][i].origin,
                destination: response[0][i].destination,
                location: location,
              });
              console.log(
                "Viagem com id: " + response[0][i].idAnnouncement + " começou"
              );
              addToMap();
            } else {
              if (location !== trip.location && location !== null) {
                testAnimate(
                  response[0][i].idAnnouncement,
                  location.latitude,
                  location.longitude
                );
              }
            }
          }
        }
        setServerInfoLoaded(true);
      });

      return () => socket.close();
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  //--------------------------------------------------------------------------

  function addToMap() {
    for (var i = 0; i < data.length; i++) {
      if (typeof filterById(onMap, data[i].idAnnouncement) === "undefined") {
        const idAnnouncement = data[i].idAnnouncement;
        onMap.push({ index: i, idAnnouncement: idAnnouncement });

        animatedRegions.push(
          new AnimatedRegion({
            latitude: data[i].location.latitude,
            longitude: data[i].location.longitude,
            latitudeDelta: LATITUDE_DELTA,
            longitudeDelta: LONGITUDE_DELTA,
          })
        );
        trip_markers.push(
          <MarkerAnimated
            anchor={{ x: 0.5, y: 0.5 }}
            coordinate={animatedRegions[i]}
            key={data[i].idAnnouncement}
            identifier={data[i].idAnnouncement + ""}
            onPress={(event) => handleMarkerPress(event)}
          >
            <Image
              style={{ height: 40 }}
              source={require("../assets/car_icon.png")}
              resizeMode={"contain"}
            />
          </MarkerAnimated>
        );
        directions.push(
          <MapViewDirections
            lineDashPattern={[0]}
            origin={{
              latitude: data[i].origin.lat,
              longitude: data[i].origin.long,
            }}
            destination={{
              latitude: data[i].destination.lat,
              longitude: data[i].destination.long,
            }}
            apikey={GOOGLE_MAPS_APIKEY}
            strokeWidth={3}
            strokeColor="black"
            key={data[i].idAnnouncement + ""}
          />
        );
      }
    }
  }

  // Gerar Marcadores consoante a info do Server
  useEffect(() => {
    if (!ServerInfoLoaded) return;
    addToMap();
  }, [ServerInfoLoaded, selected, trip_markers, animatedRegions, data]);

  // Funções Para identificar qual é o marker a ser premido
  function handleMarkerPress(event) {
    const markerID = event.nativeEvent.id;
    const trip = filterById(data, markerID);

    if (!selected || markerID !== selectedMarker) {
      selectedMarker = markerID;
      tripName = trip.destination.name;
      selected = true;
      dispatch(setTripID(markerID));
      setTripOrigin({
        latitude: trip.origin.lat,
        longitude: trip.origin.long,
      });
      setTripDestination({
        latitude: trip.destination.lat,
        longitude: trip.destination.long,
        name: tripName,
      });
    } else {
      clearMarkerInfo();
    }
  }

  function clearMarkerInfo() {
    tripName = null;
    selected = false;
    setTripOrigin(null);
    setTripDestination(null);
  }

  // Mostrar direções quando uma viagem está selecionada

  useEffect(() => {
    solo_directions = showDirections(selected);
    update({});
  }, [selected, tripOrigin, tripDestination]);

  function showDirections(selected) {
    if (selected) {
      dispatch(setDestination(tripDestination));
      dispatch(setOrigin(tripOrigin));
      return (
        <MapViewDirections
          lineDashPattern={[0]}
          origin={tripOrigin}
          destination={{
            latitude: tripDestination.latitude,
            longitude: tripDestination.longitude,
          }}
          apikey={GOOGLE_MAPS_APIKEY}
          strokeWidth={3}
          strokeColor="black"
          key="hi"
        />
      );
    } else {
      return null;
    }
  }

  useEffect(() => {
    if (!selected) return;
    // zoom & fit to markers
    mapRef.current.fitToSuppliedMarkers(["user_pos", selectedMarker], {
      edgePadding: { top: 250, right: 250, bottom: 250, left: 50 },
    });
  }, [selected, selectedMarker]);

  function testAnimate(idAnnouncement, LATITUDE, LONGITUDE) {
    const newCoordinate = {
      latitude: LATITUDE,
      longitude: LONGITUDE,
      latitudeDelta: LATITUDE_DELTA,
      longitudeDelta: LONGITUDE_DELTA,
    };

    const region = filterById(onMap, idAnnouncement);

    animatedRegions[region.index].timing(newCoordinate).start();
  }

  return (
    <View style={tw`h-full`}>
      <Animatable.Text
        animation="slideInDown"
        style={tw`bg-white  absolute top-16 w-9/12 self-center h-20 rounded-lg shadow-2xl ml-2 text-center text-lg font-semibold p-1 h-20 pt-3 `}
      >
        Selecione um dos carros disponíveis
      </Animatable.Text>
      {selected ? (
        <Animatable.View
          animation="slideInDown"
          style={tw`bg-white  absolute top-16 w-9/12 self-center h-20 rounded-lg shadow-2xl ml-2 p-1 h-24 pt-3 `}
        >
          <Text style={tw`text-center`}>Destino da viagem selecionada:</Text>
          <Text style={tw`text-center text-lg font-semibold `}>{tripName}</Text>
        </Animatable.View>
      ) : null}
      {UserInfoLoaded ? (
        <MapView
          ref={mapRef}
          style={tw`flex-1`}
          mapType="mutedStandard"
          initialRegion={{
            latitude: MyLocation.lat,
            longitude: MyLocation.lng,
            latitudeDelta: LATITUDE_DELTA,
            longitudeDelta: LONGITUDE_DELTA,
          }}
          showsUserLocation={true}
        >
          {trip_markers}
          {selected ? solo_directions : directions}
          <Marker
            coordinate={{
              latitude: MyLocation.lat,
              longitude: MyLocation.lng,
              latitudeDelta: LATITUDE_DELTA,
              longitudeDelta: LONGITUDE_DELTA,
            }}
            identifier={"user_pos"}
          >
            <Image
              source={require("../assets/youhere.png")}
              style={{ height: 35, width: 35 }}
            />
          </Marker>
        </MapView>
      ) : null}

      <TouchableOpacity
        disabled={!selected}
        style={tw`absolute bottom-10 w-3/4 self-center bg-black p-4 rounded-full ${
          !selected && "bg-gray-300"
        }`}
        onPress={() => {
          dispatch(setLocation(MyLocation));
          selected = false;
          navigation.navigate(TravelScreen);
        }}
      >
        <Text style={tw`text-center text-white text-xl`}>Confirmar Viagem</Text>
      </TouchableOpacity>
    </View>
  );
};

export default RidesScreen;

const styles = StyleSheet.create({});
