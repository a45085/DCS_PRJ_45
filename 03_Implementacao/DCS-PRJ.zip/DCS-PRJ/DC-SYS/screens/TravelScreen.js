import { useNavigation } from "@react-navigation/native";
import React, { useEffect, useRef, useState, useContext } from "react";
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Dimensions,
  ScrollView,
  BackHandler,
  Image,
} from "react-native";
import tw from "tailwind-react-native-classnames";
import { useSelector } from "react-redux";
import {
  selectLocation,
  selectOrigin,
  selectDestination,
  selectTripID,
  setTripInfoLoaded,
  selectConfirmEnd,
  selectUserID,
} from "../slices/navSlice";
import MapView, {
  Marker,
  AnimatedRegion,
  MarkerAnimated,
} from "react-native-maps";
import { _getLocationAsync } from "../getLocation";
import { SocketContext } from "../service/socket";
import { GOOGLE_MAPS_APIKEY } from "@env";
import MapViewDirections from "react-native-maps-directions";
import * as Animatable from "react-native-animatable";
import ModalPassenger from "../components/ModalPassenger";

const screen = Dimensions.get("window");
const ASPECT_RATIO = screen.width / screen.height;
const LATITUDE_DELTA = 0.0922;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

let animatedCoordinate = null;

let countEnd = 0;
let countAskTrip = 0;
const solo_directions = [];
let tripRequested = false;
let user_location = { latitude: 0, longitude: 0 };
const mapRef = React.createRef();

const TravelScreen = () => {
  const navigation = useNavigation();
  const socket = useContext(SocketContext);
  let [, update] = useState();
  const initialLocation = useSelector(selectLocation);
  const CarOrigin = useSelector(selectOrigin);
  const CarDestination = useSelector(selectDestination);
  const idAnnouncement = useSelector(selectTripID);
  const user_ID = useSelector(selectUserID);

  const [askingForTrip, setaskingForTrip] = useState(true);
  const [InfoLoaded, setInfoLoaded] = useState(false);
  const [TripEnded, setTripEnded] = useState(false);
  const [TripInfo, setTripInfo] = useState({
    username: "",
    plate: "",
    vehicle: "",
  });
  const [tripOrigin, setTripOrigin] = useState(null);
  const [tripDestination, setTripDestination] = useState(null);
  const [Loading, setLoading] = useState(true);
  const [TripResponse, setTripResponse] = useState(false);
  const [pin, setPin] = useState({
    latitude: 0,
    longitude: 0,
  });

  function testAnimate(LATITUDE, LONGITUDE, animate_coord) {
    const newCoordinate = {
      latitude: LATITUDE,
      longitude: LONGITUDE,
      latitudeDelta: LATITUDE_DELTA,
      longitudeDelta: LONGITUDE_DELTA,
    };

    animate_coord.timing(newCoordinate).start();
    // mapRef.current.animateToRegion(newCoordinate);
  }

  useEffect(() => {
    if (
      initialLocation !== null &&
      CarDestination !== null &&
      CarOrigin !== null
    ) {
      user_location = {
        latitude: initialLocation.lat,
        longitude: initialLocation.lng,
      };
      setPin(user_location);
      setTripOrigin(CarOrigin);
      setTripDestination(CarDestination);

      animatedCoordinate = new AnimatedRegion({
        latitude: CarOrigin.latitude,
        longitude: CarOrigin.longitude,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA,
      });
      setInfoLoaded(true);
      update();
    }
  }, [InfoLoaded, initialLocation, tripOrigin, tripDestination, askingForTrip]);

  useEffect(() => {
    BackHandler.addEventListener("hardwareBackPress", function () {
      return true;
    });
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      socket.emit("get driver by ID", idAnnouncement, (response) => {
        if (response !== null && typeof response !== "undefined") {
          const pathLastSpot = response.location;
          if (pathLastSpot !== null) {
            if (pathLastSpot.latitude !== 0 && pathLastSpot.longitude !== 0) {
              let coordToAnimate = animatedCoordinate;

              testAnimate(
                pathLastSpot.latitude,
                pathLastSpot.longitude,
                coordToAnimate
              );
            }
          }
        } else if (countEnd < 1) {
          countEnd++;
          setTripEnded(true);
          console.log("A viagem terminou");
        }
      });

      return () => socket.close();
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (tripRequested && Loading) {
        socket.emit("getTripResponse", socket.id, (response) => {
          if (response[0] === true && countAskTrip < 1) {
            if (response[1]) {
              countAskTrip++;
              console.log("A viagem foi aceite");
              setLoading(false);
              setTripResponse(true);
            } else {
              console.log("A viagem não foi aceite");
              setLoading(false);
              setTripResponse(false);
            }
          }
        });
      }
      return () => socket.close();
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!TripResponse) return;
    socket.emit("getTripInfo", idAnnouncement, (response) => {
      setTripInfo({
        username: response[0],
        plate: response[3],
        vehicle: response[1] + " " + response[2],
      });
    });
  }, [TripResponse]);

  function showDirections(tripRequest, LastLocation) {
    if (tripRequest && LastLocation !== null) {
      solo_directions.push(
        <MapViewDirections
          lineDashPattern={[0]}
          origin={LastLocation}
          destination={{
            latitude: tripDestination.latitude,
            longitude: tripDestination.longitude,
          }}
          waypoints={[pin]}
          apikey={GOOGLE_MAPS_APIKEY}
          strokeWidth={3}
          strokeColor="black"
          key="PICKUP"
        />
      );

      update({});
    }
  }

  return (
    <View>
      <View style={tw`h-full`}>
        {InfoLoaded ? (
          <MapView
            ref={mapRef}
            style={tw`flex-1`}
            mapType="mutedStandard"
            initialRegion={{
              latitude: initialLocation.lat,
              longitude: initialLocation.lng,
              latitudeDelta: 0.005,
              longitudeDelta: 0.005,
            }}
            showsUserLocation={true}
            ref={mapRef}
          >
            {TripResponse ? (
              <>
                <Marker
                  key="pickup"
                  coordinate={{
                    latitude: user_location.latitude,
                    longitude: user_location.longitude,
                    latitudeDelta: LATITUDE_DELTA,
                    longitudeDelta: LONGITUDE_DELTA,
                  }}
                />
                {solo_directions}
              </>
            ) : (
              <>
                <Marker
                  key="pickup"
                  draggable
                  coordinate={{
                    latitude: initialLocation.lat,
                    longitude: initialLocation.lng,
                    latitudeDelta: LATITUDE_DELTA,
                    longitudeDelta: LONGITUDE_DELTA,
                  }}
                  onDragEnd={(e) => {
                    setPin(e.nativeEvent.coordinate);
                  }}
                />
                <MapViewDirections
                  lineDashPattern={[0]}
                  origin={{
                    latitude: tripOrigin.latitude,
                    longitude: tripOrigin.longitude,
                  }}
                  destination={{
                    latitude: tripDestination.latitude,
                    longitude: tripDestination.longitude,
                  }}
                  apikey={GOOGLE_MAPS_APIKEY}
                  strokeWidth={3}
                  strokeColor="black"
                  key="hi"
                />
              </>
            )}
            {TripEnded ? null : (
              <MarkerAnimated
                coordinate={animatedCoordinate}
                key={"driver"}
                identifier={"213"}
                anchor={{ x: 0.5, y: 0.5 }}
              >
                <Image
                  style={{ height: 40 }}
                  source={require("../assets/car_icon.png")}
                  resizeMode={"contain"}
                />
              </MarkerAnimated>
            )}
          </MapView>
        ) : null}

        {Loading || !TripResponse ? (
          <>
            <Animatable.Text
              animation="slideInDown"
              style={tw`bg-white  absolute top-16 w-9/12 self-center h-20 rounded-lg shadow-2xl ml-2 text-center text-lg font-semibold p-1 h-20 pt-3 `}
            >
              Arraste o marcador para o seu local de recolha
            </Animatable.Text>
            <TouchableOpacity
              style={tw`absolute bottom-10 w-3/4 self-center bg-black p-4 rounded-full`}
              onPress={() => {
                // Enviar coordenada + Viagem pretendida
                setaskingForTrip(false);
                setLoading(true);
                tripRequested = true;
                socket.emit(
                  "pickup",
                  [idAnnouncement, pin, socket.id, user_ID],
                  (response) => {
                    showDirections(tripRequested, response);
                  }
                );
              }}
            >
              <Text style={tw`text-center text-white text-xl`}>
                Confirmar local de recolha
              </Text>
            </TouchableOpacity>
          </>
        ) : null}

        {!Loading && TripResponse ? (
          <Animatable.View
            animation="slideInDown"
            style={tw`bg-white absolute bottom-2 w-11/12 self-center h-48 rounded-lg shadow-2xl ml-2 text-lg font-semibold p-1`}
          >
            <ScrollView>
              <Text
                style={tw` text-center text-black text-xl self-center p-3 font-bold`}
              >
                @{TripInfo.username} está a caminho
              </Text>
              <Text style={tw`text-lg ml-2 text-black font-bold `}>
                Destino:
              </Text>
              <Text style={tw`text-lg mb-2 ml-2 text-black `}>
                {CarDestination.name}
              </Text>

              <View style={tw`flex-row ml-2`}>
                <View style={tw`flex-col `}>
                  <Text style={tw`text-lg text-black font-bold`}>
                    Matrícula:
                  </Text>
                  <Text style={tw`text-lg text-black font-bold `}>
                    Veículo:
                  </Text>
                </View>
                <View style={tw`flex-col`}>
                  <Text style={tw`text-lg text-black pl-4`}>
                    {TripInfo.plate}
                  </Text>
                  <Text style={tw`text-lg text-black pl-4`}>
                    {TripInfo.vehicle}
                  </Text>
                </View>
              </View>
            </ScrollView>
          </Animatable.View>
        ) : null}
      </View>
      {askingForTrip ? null : (
        <ModalPassenger
          visible_={true}
          Loading={Loading}
          Confirmed={TripResponse}
        />
      )}

      {TripEnded ? (
        <ModalPassenger
          Loading={Loading}
          Confirmed={TripResponse}
          tripEnd={TripEnded}
        />
      ) : null}
    </View>
  );
};

export default TravelScreen;

const styles = StyleSheet.create({});
