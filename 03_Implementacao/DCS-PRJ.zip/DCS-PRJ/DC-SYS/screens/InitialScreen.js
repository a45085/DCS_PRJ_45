import React, { useState, useEffect } from "react";

import {
  TextInput,
  SafeAreaView,
  TouchableOpacity,
  Text,
  Image,
  ImageBackground,
  StyleSheet,
  Button,
} from "react-native";
import tw from "tailwind-react-native-classnames";
import io from "socket.io-client";
import { useNavigation } from "@react-navigation/native";
import LoginScreen from "./LoginScreen";
import HomeScreen from "./HomeScreen";
import AsyncStorage from "@react-native-async-storage/async-storage";

const InitialScreen = () => {
  const navigation = useNavigation();

  var login = () => {
    navigation.navigate(LoginScreen);
  };

  useEffect(() => {
    getData();
  }, []);

  const getData = async () => {
    try {
      const value = await AsyncStorage.getItem("@isLoggedIn");
      const id = await AsyncStorage.getItem("@userId");
      if (JSON.parse(value)) {
        navigation.navigate(HomeScreen);
      }
    } catch (e) {
      console.log("algo correu mal" + e);
    }
  };

  return (
    <SafeAreaView style={tw`flex-1 bg-white justify-center`}>
      {/* username */}
      <ImageBackground
        source={require("../assets/background.png")}
        resizeMode="cover"
        style={tw`flex-1 bg-white justify-center`}
      >
        <Text style={tw`text-4xl text-black font-bold mx-auto`}>Dynamic</Text>
        <Text style={tw`text-4xl text-black font-bold mx-auto`}>
          Carpooling
        </Text>
        <Text style={tw`text-4xl text-black font-bold mx-auto`}>System</Text>
        <TouchableOpacity
          style={[
            tw`w-7/12  mt-10 bg-gray-400 mx-auto rounded-full items-center p-5`,
            { backgroundColor: "#db9e65" },
          ]}
          onPress={() => {
            login();
          }}
        >
          <Text style={tw`text-xl text-white font-bold`}>Login</Text>
        </TouchableOpacity>
      </ImageBackground>
      {/*} <Image source={require("../assets/dcs_logo.png")} style={tw`w-100`} /> */}
    </SafeAreaView>
  );
};

export default InitialScreen;
