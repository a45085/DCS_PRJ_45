import React, { useContext, useEffect, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Alert,
  Image,
  FlatList,
  SafeAreaView,
  ScrollView,
} from "react-native";
import tw from "tailwind-react-native-classnames";
import { Icon } from "react-native-elements";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { SocketContext } from "../service/socket";

const ProfileScreen = () => {
  const socket = useContext(SocketContext);

  const [userInfo, setUserInfo] = useState({
    userName: "",
    firstName: "",
    lastName: "",
    birthDate: "",
    userPhoto: "../assets/johnDoe.jpg",
    prestige: { points: 0, credits: 0, level: "" },
    documents: [
      { type: "", documentNumber: 0, expiryDate: "" },
      { type: "", documentNumber: "", expiryDate: "" },
    ],
    vehicles: [
      {
        idVehicle: "",
        brand: "",
        model: "",
        enginePower: 0,
        engineType: "",
        amountSeats: 5,
        photoVehicle: null,
        color: "#000000",
        registerDate: "",
        vehicleType: "",
        beltforPets: true,
        weight: 2000,
        co2Emissions: 0,
        vehiclePlate: "0",
        nationalCategory: "",
      },
    ],
    pets: [
      { breedPet: "", eletronicIdentifier: 1, weight: 0, size: 0, photo: "" },
    ],
  });
  const [fullInfo, setFullInfo] = useState(false);
  const [isDriver, setIsDriver] = useState(false);

  useEffect(() => {
    getData();
  }, []);

  const getData = async () => {
    try {
      const value = await AsyncStorage.getItem("@isLoggedIn");
      const id = await AsyncStorage.getItem("@userId");

      if (JSON.parse(value)) {
        handleSelfProfile(JSON.parse(id));
      }
    } catch (e) {
      console.log("algo correu mal");
    }
  };

  const handleSelfProfile = (userId) => {
    socket.emit("selfProfile", userId, (response) => {
      if (response[0]) {
        //simulação
        if (response[1] == 0) {
          setFullInfo(true);
          setUserInfo(response[2]);
          const documents = response[2].documents;
          for (const doc of documents) {
            if (doc.type == "driverLicense") {
              setIsDriver(true);
              break;
            }
          }
        } else {
          //dados api
          setFullInfo(false);
          setUserInfo(response[2]);
          setIsDriver(false);
        }
      } else {
        Alert.alert("Algo correu mal.");
        console.log(response[2]);
      }
    });
  };

  return (
    <SafeAreaView style={tw`bg-white flex-1`}>
      <ScrollView style={tw` mt-10`}>
        <Image
          source={require("../assets/profile.jpg")}
          style={[styles.profileImg, tw`m-2 mx-auto`]}
        />
        <Text style={tw` mx-auto text-xl font-bold`}>@{userInfo.userName}</Text>
        {fullInfo ? (
          <Text style={tw`text-3xl mt-2 text-black mx-auto`}>
            {userInfo.firstName} {userInfo.lastName}
          </Text>
        ) : (
          <View></View>
        )}
        <View style={[tw`bg-gray-300 mt-2 mb-2`, { height: 1 }]} />
        <Text style={tw`text-xl mt-1 text-black font-bold mx-auto `}>
          Prestígio
        </Text>
        <View style={tw`flex-row ml-5`}>
          <View style={tw`flex-col m-2 ml-5`}>
            <Text style={tw`text-lg pr-5  text-black `}>Pontos:</Text>
            <Text style={tw`text-lg pr-5 text-black `}>Créditos:</Text>
            <Text style={tw`text-lg pr-5 text-black `}>Nível:</Text>
          </View>
          <View style={tw`flex-col m-2 ml-5`}>
            <Text style={tw`text-lg text-black `}>
              {userInfo.prestige.points}
            </Text>
            <Text style={tw`text-lg text-black `}>
              {userInfo.prestige.credits}
            </Text>
            <Text style={tw`text-lg text-black `}>
              {userInfo.prestige.level}
            </Text>
          </View>
        </View>
        <View style={[tw`bg-gray-300 mt-1 mb-2`, { height: 1 }]} />
        {fullInfo ? (
          <View>
            <Text style={tw`text-xl  mt-1  text-black font-bold mx-auto `}>
              Data de nascimento
            </Text>
            <View style={tw`flex-row my-2 mx-auto`}>
              <Icon
                style={tw`mt-1`}
                name="calendar-outline"
                type="ionicon"
                size={20}
                color="grey"
              />
              <Text style={tw`text-lg text-black ml-4`}>
                {userInfo.birthDate}
              </Text>
            </View>
            <View style={[tw`bg-gray-300 mt-1 mb-2`, { height: 1 }]} />
            <Text style={tw`text-xl mt-1 text-black font-bold mx-auto `}>
              Documentos
            </Text>
            <Text style={tw`text-lg mt-2 ml-5 text-black font-bold `}>
              Cartão de Cidadão / Passaporte
            </Text>
            <View style={tw`flex-row ml-10`}>
              <View style={tw`flex-col mt-2`}>
                <Text style={tw`text-lg  text-black `}>
                  Número de documento:
                </Text>
                <Text style={tw`text-lg text-black ml-10`}>
                  {userInfo.documents[0].documentNumber}
                </Text>
                <Text style={tw`text-lg text-black `}>Data de expiração:</Text>
                <View style={tw`flex-row ml-10`}>
                  <Icon
                    style={tw`mt-1`}
                    name="calendar-outline"
                    type="ionicon"
                    size={20}
                    color="grey"
                  />
                  <Text style={tw`text-lg text-black ml-4`}>
                    {userInfo.documents[0].expiryDate}
                  </Text>
                </View>
              </View>
            </View>

            {isDriver ? (
              <View>
                <Text style={tw`text-lg mt-2 ml-5 text-black font-bold `}>
                  Carta de condução
                </Text>
                <View style={tw`flex-row ml-10`}>
                  <View style={tw`flex-col mt-2`}>
                    <Text style={tw`text-lg  text-black `}>
                      Número de documento:
                    </Text>
                    <Text style={tw`text-lg text-black ml-10`}>
                      {userInfo.documents[1].documentNumber}
                    </Text>
                    <Text style={tw`text-lg text-black `}>
                      Data de expiração:
                    </Text>
                    <View style={tw`flex-row ml-10`}>
                      <Icon
                        style={tw`mt-1`}
                        name="calendar-outline"
                        type="ionicon"
                        size={20}
                        color="grey"
                      />
                      <Text style={tw`text-lg text-black ml-4`}>
                        {userInfo.documents[1].expiryDate}
                      </Text>
                    </View>
                  </View>
                </View>
                {userInfo.vehicles.length > 0 ? (
                  <View>
                    <View style={[tw`bg-gray-300 mt-3`, { height: 1 }]} />
                    <Text
                      style={tw`text-xl mt-2 mb-1 text-black font-bold mx-auto `}
                    >
                      Veículos
                    </Text>
                    <FlatList
                      horizontal={true}
                      data={userInfo.vehicles}
                      keyExtractor={(item, index) => index.toString()}
                      renderItem={({ item }) => (
                        <View style={tw`border-gray-300  ml-5 border-r`}>
                          <Text style={tw`text-lg  text-black font-bold`}>
                            {item.brand} - {item.model}
                          </Text>
                          <View style={tw`flex-row mr-5`}>
                            <View style={tw`flex-col`}>
                              <Text style={tw`text-lg  text-black `}>
                                Poder do motor:
                              </Text>
                              <Text style={tw`text-lg text-black `}>
                                Tipo de motor:
                              </Text>
                              <Text style={tw`text-lg text-black `}>
                                Número de lugares:
                              </Text>
                              <Text style={tw`text-lg text-black `}>
                                Data de Registo:
                              </Text>
                              <Text style={tw`text-lg  text-black `}>
                                Tipo de veículo:
                              </Text>
                              <Text style={tw`text-lg  text-black `}>
                                Cinto para animais:
                              </Text>
                              <Text style={tw`text-lg text-black `}>Peso:</Text>
                              <Text style={tw`text-lg text-black `}>
                                Emissão de CO2:
                              </Text>
                              <Text style={tw`text-lg text-black `}>
                                Matrícula:
                              </Text>
                              <Text style={tw`text-lg text-black `}>
                                Categoria nacional:
                              </Text>
                              <Text style={tw`text-lg text-black `}>Cor:</Text>
                            </View>
                            <View style={tw`flex-col ml-2`}>
                              <Text style={tw`text-lg text-black `}>
                                {item.enginePower}
                              </Text>
                              <Text style={tw`text-lg text-black `}>
                                {item.engineType}
                              </Text>
                              <Text style={tw`text-lg text-black `}>
                                {item.amountSeats}
                              </Text>

                              <View style={tw`flex-row`}>
                                <Icon
                                  style={tw`mt-1`}
                                  name="calendar-outline"
                                  type="ionicon"
                                  size={20}
                                  color="grey"
                                />
                                <Text style={tw`text-lg text-black ml-2`}>
                                  {item.registerDate}
                                </Text>
                              </View>

                              <Text style={tw`text-lg text-black `}>
                                {item.vehicleType}
                              </Text>
                              <Text style={tw`text-lg text-black `}>
                                {item.beltforPets ? "Sim" : "Não"}
                              </Text>
                              <Text style={tw`text-lg text-black `}>
                                {item.weight} kg
                              </Text>

                              <Text style={tw`text-lg text-black`}>
                                {item.co2Emissions}
                              </Text>

                              <Text style={tw`text-lg text-black`}>
                                {item.vehiclePlate}
                              </Text>

                              <Text style={tw`text-lg text-black`}>
                                {item.nationalCategory}
                              </Text>
                              <View
                                style={{
                                  backgroundColor: item.color,
                                  borderWidth: 1,
                                  width: 50,
                                  borderColor: "black",
                                }}
                              >
                                <Text style={tw`text-lg  text-black `}> </Text>
                              </View>
                            </View>
                          </View>

                          <Text style={tw`text-lg text-black `}>
                            Foto do veículo:
                          </Text>
                          <Image
                            source={require("../assets/seat_arona.jpg")}
                            style={[styles.carImg, tw`mx-auto`]}
                          />
                        </View>
                      )}
                    />
                  </View>
                ) : (
                  <View></View>
                )}
                {userInfo.pets.length > 0 ? (
                  <View>
                    <View style={[tw`bg-gray-300 mt-1 mb-2`, { height: 1 }]} />
                    <Text
                      style={tw`text-xl mt-1 mb-3 text-black font-bold mx-auto `}
                    >
                      Animais de Estimação
                    </Text>
                    <FlatList
                      horizontal={true}
                      data={userInfo.pets}
                      keyExtractor={(item, index) => index.toString()}
                      renderItem={({ item }) => (
                        <View style={tw`border-gray-300 ml-5 border-r`}>
                          <View style={tw`flex-row mr-5`}>
                            <View style={tw`flex-col`}>
                              <Text style={tw`text-lg  text-black `}>
                                Raça:
                              </Text>
                              <Text style={tw`text-lg text-black `}>
                                Identificador E. :
                              </Text>
                              <Text style={tw`text-lg text-black `}>Peso:</Text>
                              <Text style={tw`text-lg text-black `}>
                                Tamanho:
                              </Text>
                            </View>
                            <View style={tw`flex-col ml-2`}>
                              <Text style={tw`text-lg text-black`}>
                                {item.breedPet}
                              </Text>
                              <Text style={tw`text-lg text-black `}>
                                {item.eletronicIdentifier}
                              </Text>

                              <Text style={tw`text-lg text-black `}>
                                {item.weight}
                              </Text>

                              <Text style={tw`text-lg text-black `}>
                                {item.size}
                              </Text>
                            </View>
                          </View>
                          <Text style={tw`text-lg text-black `}>Foto:</Text>
                          <Image
                            source={require("../assets/saint_bernard.jpg")}
                            style={[styles.carImg, tw`mx-auto`]}
                          />
                        </View>
                      )}
                    />
                  </View>
                ) : (
                  <View></View>
                )}
                <View style={[tw`bg-gray-300 mt-5`, { height: 1 }]} />
              </View>
            ) : (
              <View></View>
            )}
            <View style={[tw`bg-gray-300 `, { height: 1 }]} />
          </View>
        ) : (
          <View></View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

export default ProfileScreen;

const styles = StyleSheet.create({
  profileImg: {
    height: 150,
    width: 150,
    borderRadius: 80,
  },
  carImg: {
    height: 150,
    width: 150,
    resizeMode: "contain",
  },
});
