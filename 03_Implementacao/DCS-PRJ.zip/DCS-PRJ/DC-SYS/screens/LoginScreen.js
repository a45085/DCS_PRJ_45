import React, { useEffect, useContext, useState, useRef } from "react";
import {
  TextInput,
  SafeAreaView,
  TouchableOpacity,
  ImageBackground,
  Text,
  Alert,
  View,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import tw from "tailwind-react-native-classnames";
import { useNavigation } from "@react-navigation/native";
import HomeScreen from "./HomeScreen";
import { Icon } from "react-native-elements";
import AsyncStorage from "@react-native-async-storage/async-storage";
import io from "socket.io-client";
import { SERVER_URL } from "@env";
import { SocketContext } from "../service/socket";

const LoginScreen = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [hidePass, setHidePass] = useState(true);
  const [isLoading, setLoading] = useState(false);
  let userId = "";

  const navigation = useNavigation();
  // const socketUrl = SERVER_URL;
  //const socket = useRef(null);
  const socket = useContext(SocketContext);
  useEffect(() => {
    getData();
  }, []);

  /* useEffect(() => {
    socket.current = io(socketUrl);
  }, [socketUrl]);
*/
  const getData = async () => {
    try {
      const value = await AsyncStorage.getItem("@isLoggedIn");
      const id = await AsyncStorage.getItem("@userId");
      if (JSON.parse(value)) {
        navigation.navigate(HomeScreen);
      }
    } catch (e) {
      console.log("algo correu mal");
    }
  };
  const storeData = async (isLogged, userId) => {
    try {
      await AsyncStorage.setItem("@isLoggedIn", JSON.stringify(isLogged));
      await AsyncStorage.setItem("@userId", JSON.stringify(userId));
    } catch (e) {
      // saving error
    }
  };

  const handleLogin = () => {
    if (!username.trim() || !password.trim()) {
      Alert.alert("", "Preencha todos os campos.");
      setLoading(false);
      return;
    }

    setLoading(true);

    socket.emit("login", [username, password], (response) => {
      if (response[0]) {
        // setUserId(response[1]);
        console.log(" User ID : " + response[1]);
        userId = response[1];
        setLoading(false);
        storeData(true, response[1]);
        navigation.navigate(HomeScreen);
      } else {
        if (response[1] == 0) {
          Alert.alert(response[2]);
        } else {
          Alert.alert("Algo correu mal no login. Tente de novo.");
          console.log(response[2]);
        }
        setLoading(false);
      }
    });
  };

  const handleAnnouncement = (announcementId) => {
    socket.current.emit("announcement", announcementId, (response) => {
      if (response[0]) {
        console.log(" Announcement : " + JSON.stringify(response[1]));
      } else {
        Alert.alert(response[1]);
        console.log(response[1]);
      }
    });
  };

  const handleAnnouncements = () => {};

  return (
    <SafeAreaView style={tw`flex-1 bg-white justify-center`}>
      <ImageBackground
        source={require("../assets/background.png")}
        resizeMode="cover"
        style={tw`flex-1`}
      >
        {/* <TouchableOpacity
          style={tw`justify-start`}
          onClick={() => navigation.goBack()}
        >
          <Icon name="arrowleft" type="antdesign" />
        </TouchableOpacity> */}

        <View style={tw`flex-1 justify-center`}>
          <Text style={tw`text-4xl text-black font-bold mx-auto`}>Login</Text>
          {/* username */}
          <TextInput
            style={tw`w-8/12 border border-gray-800  mx-auto p-3 mt-10`}
            placeholder="Username"
            onChangeText={(text) => setUsername(text)}
          />

          <View
            style={[
              styles.password,
              tw` w-8/12 border border-gray-800 mx-auto p-3 mt-10`,
            ]}
          >
            {/* password */}
            <TextInput
              style={tw`flex-1`}
              placeholder="Password"
              secureTextEntry={hidePass ? true : false}
              password={true}
              onChangeText={(text) => setPassword(text)}
            />
            <Icon
              name={hidePass ? "eye-off-outline" : "eye-outline"}
              type="ionicon"
              size={15}
              color="grey"
              onPress={() => setHidePass(!hidePass)}
            />
          </View>
          <TouchableOpacity
            title="Login"
            style={[
              tw`w-7/12 mt-10 mx-auto rounded-full items-center p-5`,

              { backgroundColor: "#db9e65" },
            ]}
            onPress={handleLogin}
          >
            {isLoading ? (
              <ActivityIndicator
                size="small"
                color="#FFFFFF"
                animating={isLoading}
              />
            ) : (
              <Text style={tw`text-xl text-white font-bold`}>Login</Text>
            )}
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  password: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  color_green: {
    backgroundColor: "#9EC4B2",
  },
});
