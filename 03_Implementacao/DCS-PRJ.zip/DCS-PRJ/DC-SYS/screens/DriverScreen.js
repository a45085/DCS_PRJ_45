import { useNavigation } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import React, { useEffect, useRef, useState, useContext } from "react";
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Image,
  Touchable,
  Dimensions,
} from "react-native";
import tw from "tailwind-react-native-classnames";
import { useDispatch, useSelector } from "react-redux";
import {
  selectTripBegun,
  selectLocation,
  setLocation,
  setOrigin,
  setDestination,
  selectTripInfoLoaded,
  setTripInfoLoaded,
} from "../slices/navSlice";
import MapView, {
  MarkerAnimated,
  AnimatedRegion,
  Marker,
} from "react-native-maps";
import ModalDriver from "../components/ModalDriver";
import { _getLocationAsync } from "../getLocation";
import { getLocationSimulation } from "../getLocationSim";

import { Modalize } from "react-native-modalize";
import { SocketContext } from "../service/socket";
import * as Animatable from "react-native-animatable";
import MapViewDirections from "react-native-maps-directions";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { GOOGLE_MAPS_APIKEY } from "@env";

const screen = Dimensions.get("window");
const ASPECT_RATIO = screen.width / screen.height;
const LATITUDE_DELTA = 0.006339428281933124;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

let animatedCoordinate = null;
let count = 0;

let driverId = null;
//let tripInfoLoaded = false;
let tripID = null;
let infoToServer = false;
const mapRef = React.createRef();
let waypoints = [];
let simulation_index = 0;
let requestcount = 0;
//let Request = false;

const DriverScreen = () => {
  const [MyLocation, setMyLocation] = useState(null);
  const [LastPos, setLastPos] = useState(null);
  const [Loaded, setLoaded] = useState(false);
  const [EndTrip, setEndTrip] = useState(false);
  const [RequestAnswered, setRequestAnswered] = useState(false);

  // const navigation = useNavigation();

  const [tripOrigin, setTripOrigin] = useState(null);
  const [tripDestination, setTripDestination] = useState(null);

  const socket = useContext(SocketContext);
  const modalizeRef = useRef(null);
  const dispatch = useDispatch();

  // Check if trip has begun
  const tripBegun = useSelector(selectTripBegun);
  const tripInfoLoaded = useSelector(selectTripInfoLoaded);

  let [, setState] = useState();

  let countpickup = 0;

  const [UserLocation, setUserLocation] = useState(null);
  const [Username, setUsername] = useState(null);
  socket.on("TripRequest", (data) => {
    setUserLocation(data[0]);
    setUsername(data[1]);
    requestcount++;
  });

  // Get user MyLocation
  // useEffect(() => {
  //   const interval = setInterval(() => {
  //     //console.log(data[0].position);
  //     _getLocationAsync().then((data) => {
  //      if(data !== MyLocation){
  //       setMyLocation(data);
  //       socket.emit("update location", [tripID, MyLocation]);
  //      }
  //     });
  //   }, 3000);
  //   return () => clearInterval(interval);
  // }, []);

  // Simulate MyLocation
  useEffect(() => {
    const interval = setInterval(() => {
      if (tripBegun) {
        getLocationSimulation(
          tripOrigin,
          tripDestination,
          simulation_index,
          UserLocation
        ).then((data) => {
          if (data !== MyLocation) {
            setMyLocation(data);
            if (UserLocation === null) {
              setLastPos(data);
            }

            if (data !== null && simulation_index !== 0) {
              socket.emit("update location", [tripID, MyLocation]);
              testAnimate(data.latitude, data.longitude);
            }
            if (data === null && simulation_index > 0) {
              console.log("A viagem terminou");
              socket.emit("endTrip", tripID);
              setEndTrip(true);
            }

            simulation_index++;
          }
        });
      }
    }, 3000);
    return () => clearInterval(interval);
  }, [tripBegun, MyLocation, simulation_index]);

  function testAnimate(LATITUDE, LONGITUDE) {
    const newCoordinate = {
      latitude: LATITUDE,
      longitude: LONGITUDE,
      latitudeDelta: LATITUDE_DELTA,
      longitudeDelta: LONGITUDE_DELTA,
    };
    //while not answering
    animatedCoordinate.timing(newCoordinate).start();
    if (requestcount === 0) {
      mapRef.current.animateToRegion(newCoordinate);
    }
  }

  const getData = async () => {
    try {
      const id = await AsyncStorage.getItem("@userId");
      driverId = JSON.parse(id);
      handleUsersAnnouncements(driverId);
    } catch (e) {
      console.log("algo correu mal");
    }
  };

  const handleUsersAnnouncements = (userId) => {
    socket.emit("selfAnnouncement", userId, (response) => {
      if (response[0]) {
        setTripOrigin(response[1][1].origin);
        setTripDestination(response[1][1].destination);
        // Simular posição do user como se estivesse na origem da viagem
        setMyLocation({
          latitude: response[1][1].origin.lat,
          longitude: response[1][1].origin.long,
        });

        tripID = response[1][1].idAnnouncement;
        dispatch(setTripInfoLoaded(true));
      } else {
        dispatch(setTripInfoLoaded(false));
      }
    });
  };

  // Get trip at screen load
  useEffect(() => {
    getData();
  }, []);

  // Load info after aproving the beggining of the trip
  useEffect(() => {
    if (!tripBegun) return; // Check if tripBegun is true

    if (tripBegun && MyLocation !== null && !infoToServer) {
      // Load trip info to server
      socket.emit("loadDriverInfo", [tripID, socket.id, MyLocation]);
      infoToServer = true;
    }
  }, [tripBegun, MyLocation, waypoints]);

  // Update user location
  useEffect(() => {
    if (MyLocation !== null) {
      if (count < 1) {
        animatedCoordinate = new AnimatedRegion({
          latitude: MyLocation.latitude,
          longitude: MyLocation.longitude,
          latitudeDelta: LATITUDE_DELTA,
          longitudeDelta: LONGITUDE_DELTA,
        });
        count++;
      }

      setLoaded(true);

      // setState({});

      // if (
      //   MyLocation.lat !== data[0].position.lat ||
      //   MyLocation.long !== data[0].position.long
      // ) {
      //data[0].position = MyLocation;
      // console.log(MyLocation);
      // console.log("Location updated");
      //socket.emit("update location", [socket.id, MyLocation]);
      //  }
    }
  }, [MyLocation, Loaded]);

  useEffect(() => {
    if (UserLocation == null) return;
  }, [UserLocation]);

  function onOpen() {
    modalizeRef.current?.open();
  }

  function endTrip(endTrip) {
    modalizeRef.current?.close();
    endTrip ? (setEndTrip(true), socket.emit("endTrip", tripID)) : null;
  }

  useEffect(() => {
    if (UserLocation == null) return;

    mapRef.current.fitToSuppliedMarkers(["pickup", "current_pos"], {
      edgePadding: { top: 250, right: 250, bottom: 250, left: 50 },
    });
  }, [UserLocation]);

  return (
    <View>
      <View style={tw`h-full`}>
        {Loaded ? (
          <MapView
            ref={mapRef}
            style={tw`flex-1`}
            mapType="mutedStandard"
            initialRegion={{
              latitude: tripOrigin.lat,
              longitude: tripOrigin.long,
              latitudeDelta: 0.005,
              longitudeDelta: 0.005,
            }}
            showsUserLocation={true}
          >
            {UserLocation && !EndTrip ? (
              <>
                <MapViewDirections
                  lineDashPattern={[0]}
                  origin={{
                    latitude: tripOrigin.lat,
                    longitude: tripOrigin.long,
                  }}
                  destination={{
                    latitude: tripDestination.lat,
                    longitude: tripDestination.long,
                  }}
                  waypoints={[LastPos, UserLocation]}
                  apikey={GOOGLE_MAPS_APIKEY}
                  strokeWidth={3}
                  strokeColor="black"
                  key="hi"
                />

                <Marker
                  key="pickup"
                  identifier="pickup"
                  coordinate={{
                    latitude: UserLocation.latitude,
                    longitude: UserLocation.longitude,
                    latitudeDelta: LATITUDE_DELTA,
                    longitudeDelta: LONGITUDE_DELTA,
                  }}
                />
              </>
            ) : tripBegun && !EndTrip ? (
              <MapViewDirections
                lineDashPattern={[0]}
                origin={{
                  latitude: tripOrigin.lat,
                  longitude: tripOrigin.long,
                }}
                destination={{
                  latitude: tripDestination.lat,
                  longitude: tripDestination.long,
                }}
                apikey={GOOGLE_MAPS_APIKEY}
                strokeWidth={3}
                strokeColor="black"
                key="hi"
              />
            ) : null}

            <MarkerAnimated
              coordinate={animatedCoordinate}
              key={"current_pos"}
              identifier={"current_pos"}
              anchor={{ x: 0.5, y: 0.5 }}
            >
              <Image
                style={{ height: 40 }}
                source={require("../assets/car_icon.png")}
                resizeMode={"contain"}
              />
            </MarkerAnimated>
          </MapView>
        ) : null}
      </View>

      {UserLocation && !RequestAnswered ? (
        <View
          style={tw`absolute bottom-10 flex-1 flex-row justify-center w-full`}
        >
          <TouchableOpacity
            style={tw`bg-red-500 p-4 rounded-full border-2 border-white w-5/12 mx-2 shadow-xl`}
            onPress={() => {
              socket.emit("tripResponse", [tripID, false]);
              //Request = false;
              setRequestAnswered(true);
              requestcount = 0;
              setUserLocation(null);
            }}
          >
            <Text style={tw`text-center text-white text-xl`}>Não</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={tw`bg-green-500 p-4 rounded-full border-2 border-white w-5/12 mx-2 shadow-xl`}
            onPress={() => {
              socket.emit("tripResponse", [tripID, true]);
              setRequestAnswered(true);
              requestcount = 0;
              simulation_index = 0;
            }}
          >
            <Text style={tw`text-center text-white text-xl`}>Sim</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <TouchableOpacity
          style={tw`absolute bottom-10 w-3/4 self-center bg-black p-4 rounded-full`}
        >
          <Text
            style={tw`text-center text-white text-xl`}
            onPress={() => {
              onOpen();
            }}
          >
            Cancelar Viagem
          </Text>
        </TouchableOpacity>
      )}
      {/* {Animated ? ( */}
      {UserLocation && !RequestAnswered ? (
        <Animatable.View
          animation="slideInDown"
          style={tw`bg-white absolute top-10 w-9/12 self-center h-20 rounded-lg shadow-2xl ml-2 text-center text-lg font-semibold p-1 h-20 border-4 border-red-500 `}
        >
          <Text style={tw`text-lg px-5 self-center text-black font-bold `}>
            Tem um pedido de viagem!
          </Text>
          <View style={tw`flex-row`}>
            <View style={tw`flex-col m-2`}>
              <Text style={tw`text-base pr-5  text-black `}>Username:</Text>
            </View>
            <View style={tw`flex-col m-2 ml-5`}>
              <Text style={tw`text-base text-black `}>{Username}</Text>
            </View>
          </View>
        </Animatable.View>
      ) : null}
      <Modalize ref={modalizeRef} snapPoint={200} modalHeight={200}>
        <View style={tw`flex-1 flex-col`}>
          <Text style={tw`text-xl mx-4 mt-4`}>
            Tem a certeza que pretende cancelar a sua viagem?
          </Text>
          <View style={tw`flex-row justify-around my-6`}>
            <TouchableOpacity
              style={tw`bg-red-400 rounded-full p-4 items-center`}
              onPress={() => {
                endTrip(false);
              }}
            >
              <Text style={tw`text-2xl px-10`}>Não</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={tw`bg-green-400 rounded-full p-4 items-center`}
              onPress={() =>
                //socket.emit("end trip", socket.id),
                endTrip(true)
              }
            >
              <Text style={tw`text-2xl px-10`}>Sim</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modalize>
      {EndTrip ? <ModalDriver endTrip={true} /> : null}
      {tripInfoLoaded ? (
        <ModalDriver
          hasTrip={true}
          originName={tripOrigin.name}
          destinationName={tripDestination.name}
        />
      ) : (
        <ModalDriver hasTrip={false} />
      )}
    </View>
  );
};

export default DriverScreen;

const styles = StyleSheet.create({});
