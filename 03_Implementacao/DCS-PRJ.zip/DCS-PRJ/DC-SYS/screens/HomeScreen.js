import React, { useEffect, useContext, useState, useRef } from "react";
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
  FlatList,
  SafeAreaView,
  BackHandler,
} from "react-native";
import tw from "tailwind-react-native-classnames";
import { Icon } from "react-native-elements";
import { useNavigation } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import ProfileScreen from "./ProfileScreen";
import Constants from "expo-constants";
import { SocketContext } from "../service/socket";
import RidesScreen from "./RidesScreen";
import DriverScreen from "./DriverScreen";
import { setUserID } from "../slices/navSlice";
import { useDispatch } from "react-redux";

const HomeScreen = () => {
  const statusBarHeight = Constants.statusBarHeight;
  const navigation = useNavigation();
  const socket = useContext(SocketContext);
  const [isDriver, setDriver] = useState(false);
  const dispatch = useDispatch();

  useEffect(() => {
    getData();
    BackHandler.addEventListener("hardwareBackPress", function () {
      return true;
    });
  }, []);

  const getData = async () => {
    try {
      const value = await AsyncStorage.getItem("@isLoggedIn");
      const id = await AsyncStorage.getItem("@userId");

      if (JSON.parse(value)) {
        handleCheckDocuments(JSON.parse(id));
        dispatch(setUserID(JSON.parse(id)));
      }
    } catch (e) {
      console.log("algo correu mal");
    }
  };
  const handleCheckDocuments = (userId) => {
    socket.emit("selfProfile", userId, (response) => {
      if (response[0]) {
        //simulação
        if (response[1] == 0) {
          const documents = response[2].documents;
          const vehicles = response[2].vehicles;
          for (const doc of documents) {
            if (doc.type == "driverLicense" && vehicles.length > 0) {
              setDriver(true);
              break;
            }
          }
        }
      } else {
        Alert.alert("Algo correu mal.");
      }
    });
  };

  const loggout = async () => {
    try {
      await AsyncStorage.setItem("@isLoggedIn", JSON.stringify(false));
      await AsyncStorage.setItem("@userId", "");
      BackHandler.addEventListener("hardwareBackPress", function () {
        return false;
      });
      navigation.popToTop();
    } catch (e) {
      // saving error
    }
  };

  return (
    <SafeAreaView style={[tw`bg-white flex-1`, { marginTop: statusBarHeight }]}>
      <View style={tw`flex-row mt-2 w-full justify-between bg-white`}>
        <TouchableOpacity
          style={tw`w-4/12 items-center p-2`}
          onPress={() => {
            navigation.navigate(ProfileScreen);
          }}
        >
          <View style={tw`flex-row mx-auto `}>
            <Icon
              style={tw`mt-1 mr-3`}
              name="person-outline"
              type="ionicon"
              size={20}
              color="black"
            />
            <Text style={tw`text-xl text-black`}>Perfil</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          style={tw`w-4/12 items-center p-2`}
          onPress={() => {
            loggout();
          }}
        >
          <Text style={tw`text-xl  font-bold`}>Logout</Text>
        </TouchableOpacity>
      </View>
      <View style={[tw`bg-gray-300 mt-2`, { height: 1 }]} />
      <View style={[tw`p-5`]}>
        {/*componente relativo às opções de navegação */}
        <Text style={tw`text-4xl mt-5 text-black  font-bold mx-auto`}>
          Entrar como{" "}
        </Text>
        <TouchableOpacity
          horizontal
          onPress={() => navigation.navigate(RidesScreen)} //navigate recebe o nome do ecrã (String) definido em stack screen (neste caso a info está em item.screen)
          style={[
            tw`pl-6 p-12 mt-10  mx-auto w-10/12  rounded-xl shadow-xl border-2 border-white`,
            { backgroundColor: "#db9e65" },
          ]}
        >
          <View style={tw`flex-row justify-between  items-center`}>
            {/* <View> */}
            <Text style={tw`text-2xl text-white font-semibold `}>
              Passageiro
            </Text>
            <Icon
              style={tw`p-2 rounded-full border-2 border-white`}
              name="arrowright"
              color="white"
              type="antdesign"
            />
          </View>
        </TouchableOpacity>
        {isDriver ? (
          <TouchableOpacity
            horizontal
            onPress={() => navigation.navigate(DriverScreen)} //navigate recebe o nome do ecrã (String) definido em stack screen (neste caso a info está em item.screen)
            style={[
              tw`pl-6 p-12 mt-10  mx-auto w-10/12  rounded-xl shadow-xl border-2 border-white`,
              { backgroundColor: "#263636" },
            ]}
          >
            <View style={tw`flex-row justify-between items-center`}>
              {/* <View> */}
              <Text style={tw`text-2xl text-white font-semibold `}>
                Condutor
              </Text>
              <Icon
                style={tw`p-2 rounded-full border-2 border-white `}
                name="arrowright"
                color="white"
                type="antdesign"
              />
            </View>
          </TouchableOpacity>
        ) : (
          <View></View>
        )}
      </View>
    </SafeAreaView>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({});
