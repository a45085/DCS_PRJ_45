import io from "socket.io-client";
import { SERVER_URL } from "@env";
import React from "react";

export const socket = io(SERVER_URL);
export const SocketContext = React.createContext();
